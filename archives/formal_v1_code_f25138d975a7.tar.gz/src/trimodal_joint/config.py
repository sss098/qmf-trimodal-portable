"""Strict, serializable experiment configuration."""

from dataclasses import asdict, dataclass
from pathlib import Path

import yaml


@dataclass(frozen=True)
class Config:
    source_project: str = "/home/wp24/mix/sarcopenia_original_us_trimodal_5fold - new"
    clinical_excel: str = "/home/wp24/mix/肌少症患者数据统计修改版2 - 副本.xlsx"
    raw_root: str = "/home/wp24/mix/更新数据"
    imagenet_weights: str = "/home/wp24/.cache/torch/hub/checkpoints/resnet50-11ad3fa6.pth"
    output: str = "/home/wp24/mix/qmf_trimodal_joint_v1_4/artifacts"
    epochs: int = 100
    patience: int = 12
    batch_size: int = 6
    windows_per_segment: int = 8
    lr: float = 2e-4
    encoder_lr: float = 1e-5
    weight_decay: float = 1e-3
    rank_weight: float = 0.1
    split_seed: int = 20260911
    device: str = "cuda"
    threads: int = 2

    def validate(self) -> None:
        for key in ["epochs", "patience", "batch_size", "windows_per_segment", "threads"]:
            value = getattr(self, key)
            if not isinstance(value, int) or isinstance(value, bool) or value < 1:
                raise ValueError(f"{key} must be a positive integer")
        if self.epochs > 100:
            raise ValueError("Maximum training budget is 100 epochs")
        if self.windows_per_segment > 331:
            raise ValueError("windows_per_segment exceeds available windows")
        for key in ["lr", "encoder_lr"]:
            if not 0 < getattr(self, key) < 1:
                raise ValueError(f"Invalid {key}")
        if self.weight_decay < 0 or self.rank_weight < 0 or self.device not in ("cpu", "cuda"):
            raise ValueError("Invalid regularization or device")

    def to_dict(self) -> dict:
        return asdict(self)


def load_config(path: Path | None) -> Config:
    values = {} if path is None else yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(values, dict):
        raise ValueError("Config must be a YAML mapping")
    unknown = set(values) - set(Config.__dataclass_fields__)
    if unknown:
        raise ValueError(f"Unknown config fields: {sorted(unknown)}")
    config = Config(**values)
    config.validate()
    return config
