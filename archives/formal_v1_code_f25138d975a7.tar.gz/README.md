# 六通道 FT-Transformer 三模态联合训练

本项目用同一套 ResNet50、六通道 FTTransformerRaw、表格 MLP，分别训练 `equal_late`、`qmf`、`tmc`。EMG网络直接适配“肌电分类程序/2-FT-Transformer-v1.4-年龄二分类.py”的窗口模型，原始参考代码保存在 `third_party/`。

## 已固定的输入与标签

- 85名患者，表格分组62阳性/23阴性。表格B/C两列唯一决定标签；不使用图像/EMG文件夹中的类别名或旧缓存标签，不按握力/DXA重算。
- 当前磁盘Excel B2/C2文字仍为“低肌肉量组/非低肌肉量组”，实验显示名按用户要求为“肌少症/非肌少症”。原表头同时保存到manifest，不能把显示名变更当作诊断标准变更。
- 超声使用v1.4既有ROI，每人2–14张；表格95项候选，按训练集删除高缺失/常数列、中位数填补和标准化。
- EMG从原始采集CSV重建，复用v1.1患者及电极映射审计；不是旧的985×6×8特征缓存。五段10秒收缩，每段100点窗/30点步长产生331窗，每人1655窗。
- 三分支从第1轮同时更新。ResNet50只加载本地ImageNet1K V2骨干；不加载本任务的单分支训练权重。

## 使用当前环境

本机已安装项目及所需PyWavelets、Ruff。解释器为：

```bash
cd /home/wp24/mix/qmf_trimodal_joint_v1_4
/home/wp24/miniconda3/envs/mix/bin/python -m trimodal_joint.cli prepare --config configs/base.yaml
```

准备命令只校验/构建缓存，不训练。路径全部可在 `configs/base.yaml` 修改。准备缓存约337 MB原始窗口，训练折的特征缓存每组约81 MB；选择和重训阶段各自缓存。原始数据不改写。

在新的环境安装：

```bash
python -m pip install -e '.[dev]'
```

`requirements-tested.txt`记录本机验证版本；PyTorch应根据设备的CUDA支持安装。不要直接运行third_party原脚本，它们含原任务训练入口。

## 正式训练：三方法、三种子、五折

```bash
cd /home/wp24/mix/qmf_trimodal_joint_v1_4
/home/wp24/miniconda3/envs/mix/bin/python -m trimodal_joint.cli train \
  --config configs/base.yaml \
  --methods equal_late,qmf,tmc \
  --seeds 42,43,44 \
  --folds 0,1,2,3,4 \
  --name formal_v1 \
  --resume
```

三方法按顺序执行，不并行占用GPU。45个外层实验，每个含选择与重训，共90次训练过程。

单独训练QMF：

```bash
/home/wp24/miniconda3/envs/mix/bin/python -m trimodal_joint.cli train \
  --config /home/wp24/mix/qmf_trimodal_joint_v1_4/configs/base.yaml \
  --methods qmf --seeds 42,43,44 --folds 0,1,2,3,4 --name qmf_v1 --resume
```

仅做短程验证：

```bash
/home/wp24/miniconda3/envs/mix/bin/python -m trimodal_joint.cli train \
  --config /home/wp24/mix/qmf_trimodal_joint_v1_4/configs/base.yaml \
  --smoke --name local_check --resume
```

`--smoke`强制seed42/fold0、选择1轮+重训1轮，并添加`_smoke`输出目录后缀，不能当正式五折结果。

恢复使用相同命令和`--resume`，从最近完整epoch继续；进程在epoch内中断会重跑该epoch。checkpoint包含模型、优化器、全部随机状态、QMF历史、TMC轮次和数据/代码指纹。更改配置、源数据、权重或运行代码后应换`--name`；不允许把不同条件混成一个结果。不要同时启动同名实验或同时构建同一缓存。

## 实际训练参数

| 项目 | 值 |
|---|---|
| 最大轮数 | 100，校验拒绝大于100 |
| 早停 | 验证患者未加权log loss连续12轮不下降 |
| 优化器 | AdamW，betas=(0.9,0.999)，eps=1e-8 |
| ResNet50骨干学习率 | 1e-5 |
| 超声新分类头、EMG、表格学习率 | 2e-4 |
| Weight decay | 1e-3，全部参数 |
| Batch size | 6位患者，无放回shuffle，不丢最后一批 |
| EMG训练窗口 | 每段8个，共40个/患者，每轮重新随机取窗 |
| 超声训练输入 | 每患者随机1张，水平翻转0.5、亮度0.92–1.08、对比度0.90–1.10 |
| EMG结构 | 6通道、128维、8头、4层、FFN256、dropout0.2 |
| EMG手工特征 | 每通道24项；LayerNorm→24→128→128后加到波形token |
| 表格结构 | D→64→32→2，LayerNorm64，GELU，dropout0.2 |
| 超声头 | Dropout0.35→Linear(2048,2) |
| 梯度裁剪 | 全模型L2 norm5，非有限梯度报错 |
| AMP/调度器/学习率warmup | 均关闭；float32固定学习率 |
| 冻结层/分支预训练 | 均无 |
| 类别权重 | 当前训练集N/(2*n_class)，只用于分类/证据损失 |
| 种子 | 42、43、44；每折初始化seed+fold |
| 患者划分 | seed20260911，分层5折 |
| 分类阈值 | 阳性概率≥0.5 |

EMG参数572274。超声骨干23508032＋分类头4098；表格64D+2338，D=95时8418。D=95时合计24092822个参数。各折`parameters.json`记录实际维数和参数量。

## 前向与反向传播

超声ROI→ResNet50→2 logits；EMG每窗原始波形+手工特征→FTTransformerRaw→2 logits→患者窗口均值；表格→MLP→2 logits。三个患者输出进入融合公式。总损失一次backward，统一optimizer.step更新所有分支。

训练每位患者抽样40窗；验证和测试使用所有1655窗，按段均值后五段等权平均（固定每段331窗，与全窗均值一致）。超声验证/测试使用所有ROI，先平均超声logits，再融合一次。多图/多窗不会重复累计为额外独立模态。手工特征的提取不是可训练网络，但其后的特征MLP可训练。

选择阶段：51训练/17验证，测试折完全隔离；用最佳验证log loss选轮数E。随后全新初始化，在68名非测试患者上重训E轮，再评估17名测试患者。预处理、优化器和QMF历史都重新开始。

## 与原仓库一致及适配之处

- **等权**：三个logits取均值。损失=融合CE+三个单分支CE，每项系数1。
- **QMF**：严格采用RGB-D路径`q=logsumexp(z)/10`、`sum(q*z)`，不对权重归一化、不detach质量分数。损失=融合CE+三个分支CE+0.1×三个排名损失。历史采用原RGB-D累计逐患者未加权CE，当前批次先排名后更新历史；不是早期方案的epoch快照/历史平均。每轮患者无放回遍历，第一轮每批当前患者无历史，排序自然为零。历史从不读取验证或测试标签。
- **TMC**：softplus证据、alpha=e+1、DS融合、期望CE+KL；KL前10轮从0.1升到1。融合项与每个分支项系数均1。代码使用DS原公式的代数等价形式`e_ab=e_a+e_b+e_a*e_b/K`，避免高冲突时除以接近零的数；不是另一种融合规则。概率使用alpha/sum(alpha)。
- 两模态改三模态、原16通道改6通道、患者级采样/聚合、类别加权、患者级五折与差异学习率属于明确适配。原脚本的年龄标签和文件级拆分不沿用。
- EMG网络无独立全程统计分支、无第二级时序Transformer。原窗口程序的逐通道手工特征路径保留。
- 特征提取与原程序数值对照；唯一数值保护是全零频谱中值频率索引越界防护。PyWavelets为强制依赖，不静默输出零小波特征。
- ROI预处理沿用v1.4的thumbnail补边；小图保持原尺度，不放大到填满画布。

## 输出和检查

输出在`artifacts/runs/<name>/<method>/seed<seed>/fold<fold>/`：

- `selection/`、`refit/`各阶段预处理、划分、参数量、逐轮历史、选择轮次、可恢复`last.pt`。
- `model.pt`最终推理参数及预处理状态。
- `predictions.json`与`metrics.json`患者级测试结果。
- 种子级`oof_predictions.csv`与汇总。
- 方法级`ensemble_predictions.csv`、种子均值/标准差及集成指标。
- 根目录`comparison.json`为本次请求的方法比较；单折运行明确标记非完整五折。

指标包括ROC-AUC、PR-AUC（average precision）、ACC、balanced ACC、敏感度、特异度、F1、Brier、log loss及混淆矩阵。QMF输出原始质量分数；TMC输出alpha与不确定度。

运行验证：

```bash
python -m ruff check src tests
python -m ruff format --check src tests
python -m pytest -q
```

正式性能结论必须来自完整五折，短程验证仅证明流程能运行。模型检查点通过PyTorch保存；只恢复本项目自己生成且可信的检查点。
