# Implementation checklist

- [x] Validate table labels, patient linkage, raw EMG and fixed channel audit.
- [x] Preserve original FT-Transformer and feature extraction; verify formulas/gradients with tests.
- [x] Implement patient sampling, fold-local preprocessing, selection/refit and resumable checkpoints.
- [x] Check all three methods with real-data smoke runs; independent code review.
- [x] Deliver locked configuration, provenance, commands and limitations.

Scope: this project only; no original source or data mutation; 100 max epochs; table labels authoritative; local ImageNet ResNet50 initialization; no task branch pretraining.
