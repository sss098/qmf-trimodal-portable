#!/usr/bin/env bash
# Evaluate existing final checkpoints; no training or optimizer updates.
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
export PYTHONPATH="$project_dir/src${PYTHONPATH:+:$PYTHONPATH}"
/home/wp24/miniconda3/envs/mix/bin/python reports/qmf_robustness.py "$@"
