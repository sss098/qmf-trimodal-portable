#!/usr/bin/env bash
# Matched augmented equal fusion and QMF, in a separate run directory.
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
export PYTHONPATH="$project_dir/src${PYTHONPATH:+:$PYTHONPATH}"
/home/wp24/miniconda3/envs/mix/bin/python -m trimodal_joint.cli train \
  --config configs/noise_aug_v1.yaml --methods equal_late,qmf \
  --seeds 42,43,44 --folds 0,1,2,3,4 --name noise_aug_v1 --resume "$@"
