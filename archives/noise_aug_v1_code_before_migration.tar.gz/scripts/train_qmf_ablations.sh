#!/usr/bin/env bash
# Train both ranking ablations sequentially on the same GPU.
set -euo pipefail
project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"
export PYTHONPATH="$project_dir/src${PYTHONPATH:+:$PYTHONPATH}"
python_bin=/home/wp24/miniconda3/envs/mix/bin/python

"$python_bin" -m trimodal_joint.cli train \
  --config configs/base.yaml --methods qmf \
  --seeds 42,43,44 --folds 0,1,2,3,4 \
  --rank-mode positive_margin --rank-weight 0 \
  --name qmf_rank0_v1 --resume

"$python_bin" -m trimodal_joint.cli train \
  --config configs/base.yaml --methods qmf \
  --seeds 42,43,44 --folds 0,1,2,3,4 \
  --rank-mode original --rank-weight 0.1 \
  --name qmf_rank_original_v1 --resume
